#include <stdio.h>

int dobrar_por_valor(int x) {
    x = x * 2;
    return x; 
}

void dobrar_por_referencia(int *x) {
    *x = *x * 2;    
}

int main() {
    int numero = 10;
    int resultado_valor;
    
    printf("=== EXERCÍCIO 1 - PASSAGEM DE PARÂMETROS ===\n\n");
    printf("Valor inicial da variável: %d\n\n", numero);
    
    printf("--- Teste da função dobrar por VALOR ---\n");
    printf("Antes da chamada: numero = %d\n", numero);
    resultado_valor = dobrar_por_valor(numero);
    printf("Depois da chamada: numero = %d\n", numero);
    printf("Valor retornado pela função: %d\n\n", resultado_valor);
    
    printf("--- Teste da função dobrar por REFERÊNCIA ---\n");
    printf("Antes da chamada: numero = %d\n", numero);
    dobrar_por_referencia(&numero);
    printf("Depois da chamada: numero = %d\n\n", numero);
    
    printf("=== ANÁLISE DOS RESULTADOS ===\n");
    printf("• Na passagem por VALOR: a variável original não foi alterada\n");
    printf("• Na passagem por REFERÊNCIA: a variável original foi modificada\n");
    printf("• Isso acontece porque:\n");
    printf("  - Por valor: uma cópia do valor é passada para a função\n");
    printf("  - Por referência: o endereço da variável é passado, permitindo modificação direta\n");
    
    return 0;
}
