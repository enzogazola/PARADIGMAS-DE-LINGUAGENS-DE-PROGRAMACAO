
"""
Exercício 1 - Capítulo 9: Passagem de Parâmetros por Valor e por Referência
Demonstração em Python (Python sempre passa por referência para objetos mutáveis)
"""

def dobrar_por_valor(x):
    """
    Simula passagem por valor - retorna o valor dobrado
    Em Python, números são imutáveis, então funciona como passagem por valor
    """
    x = x * 2
    return x

def dobrar_por_referencia(lista):
    """
    Simula passagem por referência usando uma lista
    Em Python, listas são mutáveis, então modificamos diretamente
    """
    lista[0] = lista[0] * 2

def main():
    print("=== EXERCÍCIO 1 - PASSAGEM DE PARÂMETROS (PYTHON) ===\n")
    
    numero = 10
    print(f"Valor inicial: {numero}")
    
    print("\n--- Teste com número (comportamento similar a passagem por VALOR) ---")
    print(f"Antes da chamada: numero = {numero}")
    resultado = dobrar_por_valor(numero)
    print(f"Depois da chamada: numero = {numero}")
    print(f"Valor retornado pela função: {resultado}")
    
    lista_numero = [10] 
    print(f"\n--- Teste com lista (comportamento similar a passagem por REFERÊNCIA) ---")
    print(f"Antes da chamada: lista_numero = {lista_numero}")
    dobrar_por_referencia(lista_numero)
    print(f"Depois da chamada: lista_numero = {lista_numero}")
    
    print("\n=== ANÁLISE DOS RESULTADOS ===")
    print("• Com número: a variável original não foi alterada (comportamento similar a passagem por valor)")
    print("• Com lista: a variável original foi modificada (comportamento similar a passagem por referência)")
    print("• Em Python:")
    print("  - Números são imutáveis, então não podem ser modificados dentro da função")
    print("  - Listas são mutáveis, então podem ser modificadas diretamente")
    print("  - Isso demonstra os conceitos de passagem por valor vs. referência")

if __name__ == "__main__":
    main()
