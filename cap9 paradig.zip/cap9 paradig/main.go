package main

import (
    "fmt"
    "time"
)

func escrever(texto string) {
    for i := 0; i < 5; i++ {
        fmt.Println(texto, i)
        time.Sleep(time.Millisecond * 500)
    }
}

func main() {
    fmt.Println("=== EXERCÍCIO 2 - CORROTINAS EM GOLANG ===")
    fmt.Println("Iniciando execução...\n")
    
    go escrever("Corrotina")
    
    escrever("Função normal")
    
    time.Sleep(time.Second * 3)
    
    fmt.Println("\n=== ANÁLISE DO COMPORTAMENTO ===")
    fmt.Println("• As mensagens se intercalam porque:")
    fmt.Println("  - A corrotina executa concorrentemente com o fluxo principal")
    fmt.Println("  - Ambas as funções compartilham o mesmo tempo de CPU")
    fmt.Println("  - O sistema operacional alterna entre elas")
    fmt.Println("• Isso demonstra o conceito de corrotinas:")
    fmt.Println("  - Execução concorrente de rotinas")
    fmt.Println("  - Compartilhamento cooperativo de recursos")
    fmt.Println("  - Não há preempção - as rotinas cooperam entre si")
}
