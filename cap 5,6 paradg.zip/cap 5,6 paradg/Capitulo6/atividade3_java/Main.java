public class Main {
    public static void main(String[] args) {
        int num = 10;
        // num = "dez"; // ERRO de compilação se descomentado: tipos incompatíveis
        System.out.println(num + 5); // 15
    }
}


