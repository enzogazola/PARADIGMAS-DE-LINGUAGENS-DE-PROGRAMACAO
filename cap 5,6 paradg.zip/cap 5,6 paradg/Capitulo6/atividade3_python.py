"""
Capítulo 6 – Atividade 3 (Python)
Tipagem dinâmica e coerção em runtime.
"""

num = 10
print(num + 5)  # 15

num = "dez"  # agora num é string
try:
    print(num + 5)
except TypeError as e:
    print("TypeError ao somar string e int:", e)


