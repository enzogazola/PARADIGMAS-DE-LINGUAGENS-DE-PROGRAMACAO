import java.util.*;

class Livro {
    String titulo;
    String autor;
    int anoPublicacao;

    Livro(String titulo, String autor, int anoPublicacao) {
        this.titulo = titulo;
        this.autor = autor;
        this.anoPublicacao = anoPublicacao;
    }
}

public class Main {
    public static void main(String[] args) {
        List<Livro> livros = new ArrayList<>();
        livros.add(new Livro("Clean Code", "Robert C. Martin", 2008));
        livros.add(new Livro("Effective Java", "Joshua Bloch", 2018));
        livros.add(new Livro("Refactoring", "Martin Fowler", 2018));

        for (Livro l : livros) {
            System.out.println(l.titulo);
        }
    }
}


