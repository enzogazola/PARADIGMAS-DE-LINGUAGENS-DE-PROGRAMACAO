#include <stdio.h>

/*
Capítulo 6 – Atividade 4 (C)
Array homogêneo e struct (registro) heterogêneo.
*/

typedef struct {
    char titulo[100];
    char autor[100];
    int anoPublicacao;
} Livro;

int main() {
    // Array de inteiros
    int arr[5] = {1, 3, 5, 7, 9};
    for (int i = 0; i < 5; i++) {
        // Apenas demonstração de uso; não é necessário imprimir
        (void)arr[i];
    }

    // Struct Livro
    Livro l = {"O Programador Pragmático", "Andrew Hunt e David Thomas", 1999};
    printf("%s\n", l.titulo);
    return 0;
}


