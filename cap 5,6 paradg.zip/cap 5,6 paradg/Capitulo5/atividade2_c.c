#include <stdio.h>

/*
Capítulo 5 – Atividade 2 (C)
Variáveis automática (a) e estática (b).
Chamadas sucessivas mostram a reinicialização de a e a persistência de b.
*/

void contador() {
    int a = 0;        // automática: recriada a cada chamada
    static int b = 0; // estática: persiste entre chamadas
    a++;
    b++;
    printf("a = %d, b = %d\n", a, b);
}

int main() {
    contador();
    contador();
    contador();
    return 0;
}


