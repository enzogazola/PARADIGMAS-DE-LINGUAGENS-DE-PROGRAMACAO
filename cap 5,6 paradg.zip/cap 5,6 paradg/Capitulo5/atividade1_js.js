/*
Capítulo 5 – Atividade 1 (JavaScript)
Escopo léxico (estático): f resolve x onde foi definida.

Execução esperada:
g() imprime 10; o x local de g não altera o x acessado por f.
*/

let x = 10; // global (arquivo)

function f() {
  console.log(x);
}

function g() {
  let x = 20; // local a g
  f();
}

g(); // imprime 10


