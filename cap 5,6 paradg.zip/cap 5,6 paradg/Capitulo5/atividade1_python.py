"""
Capítulo 5 – Atividade 1 (Python)
Escopo estático (léxico): a função f resolve x onde foi definida.

Execução esperada:
g() imprime 10, pois o x local de g não sombreia a resolução de f.
"""

x = 10  # global


def f():
    print(x)


def g():
    x = 20  # local a g, não afeta o global
    f()


if __name__ == "__main__":
    g()  # imprime 10


