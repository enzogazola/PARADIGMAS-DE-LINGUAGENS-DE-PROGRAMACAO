def quadrado(num):
    """Calcula o quadrado de um número"""
    return num * num

def fatorial(num):
    """Calcula o fatorial de um número"""
    if num < 0:
        return -1  
    if num == 0 or num == 1:
        return 1
    
    resultado = 1
    for i in range(2, num + 1):
        resultado *= i
    return resultado

def main():
    print("=== MENU INTERATIVO (IMPLEMENTAÇÃO EM PYTHON) ===")
    
    while True:
        print("\nEscolha uma opção:")
        print("1. Calcular o quadrado de um número")
        print("2. Calcular o fatorial de um número")
        print("3. Sair do programa")
        
        try:
            opcao = int(input("Digite sua opção (1-3): "))
        except ValueError:
            print("Erro: Digite um número válido!")
            continue
        
        if opcao == 1:
            try:
                numero = int(input("Digite um número: "))
                print(f"O quadrado de {numero} é: {quadrado(numero)}")
            except ValueError:
                print("Erro: Digite um número válido!")
                
        elif opcao == 2:
            try:
                numero = int(input("Digite um número: "))
                if numero < 0:
                    print("Erro: Fatorial não está definido para números negativos.")
                elif numero > 20:
                    print("Erro: Número muito grande para calcular o fatorial.")
                else:
                    print(f"O fatorial de {numero} é: {fatorial(numero)}")
            except ValueError:
                print("Erro: Digite um número válido!")
                
        elif opcao == 3:
            print("Saindo do programa...")
            break
            
        else:
            print("Opção inválida! Digite um número entre 1 e 3.")

if __name__ == "__main__":
    main()
