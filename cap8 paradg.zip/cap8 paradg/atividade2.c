#include <stdio.h>
#include <stdlib.h>

int quadrado(int num) {
    return num * num;
}

long long fatorial(int num) {
    if (num < 0) return -1; 
    if (num == 0 || num == 1) return 1;
    
    long long resultado = 1;
    for (int i = 2; i <= num; i++) {
        resultado *= i;
    }
    return resultado;
}

int main() {
    int opcao, numero;
    
    printf("=== MENU INTERATIVO (IMPLEMENTAÇÃO EM C) ===\n");
    
    do {
        printf("\nEscolha uma opção:\n");
        printf("1. Calcular o quadrado de um número\n");
        printf("2. Calcular o fatorial de um número\n");
        printf("3. Sair do programa\n");
        printf("Digite sua opção (1-3): ");
        scanf("%d", &opcao);
        
        switch (opcao) {
            case 1:
                printf("Digite um número: ");
                scanf("%d", &numero);
                printf("O quadrado de %d é: %d\n", numero, quadrado(numero));
                break;
                
            case 2:
                printf("Digite um número: ");
                scanf("%d", &numero);
                if (numero < 0) {
                    printf("Erro: Fatorial não está definido para números negativos.\n");
                } else if (numero > 20) {
                    printf("Erro: Número muito grande para calcular o fatorial.\n");
                } else {
                    printf("O fatorial de %d é: %lld\n", numero, fatorial(numero));
                }
                break;
                
            case 3:
                printf("Saindo do programa...\n");
                break;
                
            default:
                printf("Opção inválida! Digite um número entre 1 e 3.\n");
                break;
        }
        
    } while (opcao != 3);
    
    return 0;
}
