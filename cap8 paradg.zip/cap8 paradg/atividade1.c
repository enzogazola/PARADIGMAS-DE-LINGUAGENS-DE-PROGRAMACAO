#include <stdio.h>

int main() {
    printf("=== ATIVIDADE 1 - COMPARAÇÃO DE ESTRUTURAS DE REPETIÇÃO ===\n\n");
    
    printf("1. VERSÃO ORIGINAL COM GOTO:\n");
    printf("i := 1\n");
    printf("goto check\n\n");
    printf("loop:\n");
    printf("    print(i)\n");
    printf("    i := i + 1\n\n");
    printf("check:\n");
    printf("    if (i <= 10) then\n");
    printf("        goto loop\n\n");
    
    printf("2. VERSÃO COM WHILE (PRÉ-TESTE):\n");
    int i = 1;
    while (i <= 10) {
        printf("%d ", i);
        i++;
    }
    printf("\n\n");
    
    printf("3. VERSÃO COM FOR (CONTROLADO POR CONTADOR):\n");
    for (int j = 1; j <= 10; j++) {
        printf("%d ", j);
    }
    printf("\n\n");
    
    printf("=== ANÁLISE COMPARATIVA ===\n");
    printf("O código original com 'goto' é funcionalmente equivalente às versões modernas,\n");
    printf("mas apresenta várias desvantagens:\n");
    printf("- Dificulta a leitura e compreensão do fluxo do programa\n");
    printf("- Pode criar 'código espaguete' em programas maiores\n");
    printf("- Torna a manutenção mais complexa\n");
    printf("- Não segue as boas práticas de programação estruturada\n\n");
    printf("A versão com 'while' é mais legível pois:\n");
    printf("- Deixa claro que é um laço de repetição\n");
    printf("- A condição de parada é explícita\n");
    printf("- O fluxo é linear e fácil de seguir\n\n");
    printf("A versão com 'for' é ainda mais clara pois:\n");
    printf("- Concentra inicialização, condição e incremento em uma linha\n");
    printf("- É ideal para laços controlados por contador\n");
    printf("- Reduz a possibilidade de erros (como esquecer de incrementar)\n");
    printf("- É mais concisa e expressiva para este tipo de problema\n");
    
    return 0;
}
