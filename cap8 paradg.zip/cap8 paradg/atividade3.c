#include <stdio.h>

int processar_lista(int lista[], int tamanho) {
    printf("=== PROCESSANDO LISTA COM ALTERNATIVAS AO GOTO ===\n");
    printf("Lista: ");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", lista[i]);
    }
    printf("\n\n");
    
    for (int i = 0; i < tamanho; i++) {
        printf("Processando elemento %d: %d\n", i, lista[i]);
        
        if (lista[i] == 0) {
            printf("  -> Encontrado 0! Parando execução com BREAK.\n");
            break;
        }
        
        if (lista[i] < 0) {
            printf("  -> Número negativo encontrado! Pulando com CONTINUE.\n");
            continue;
        }
        
        if (lista[i] % 2 == 0) {
            printf("  -> Primeiro número par encontrado! Retornando o dobro com RETURN.\n");
            return lista[i] * 2;
        }
        
        printf("  -> Número ímpar processado normalmente.\n");
    }
    
    printf("Nenhum número par encontrado antes de encontrar 0 ou negativo.\n");
    return -1; 
}

int processar_lista_com_goto(int lista[], int tamanho) {
    printf("\n=== VERSÃO COM GOTO (PARA COMPARAÇÃO) ===\n");
    printf("Lista: ");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", lista[i]);
    }
    printf("\n\n");
    
    int i = 0;
    
    inicio_loop:
    if (i >= tamanho) goto fim_loop;
    
    printf("Processando elemento %d: %d\n", i, lista[i]);
    
    if (lista[i] == 0) {
        printf("  -> Encontrado 0! Parando execução com GOTO.\n");
        goto fim_loop;
    }
    
    if (lista[i] < 0) {
        printf("  -> Número negativo encontrado! Pulando com GOTO.\n");
        i++;
        goto inicio_loop;
    }
    
    if (lista[i] % 2 == 0) {
        printf("  -> Primeiro número par encontrado! Retornando o dobro com GOTO.\n");
        return lista[i] * 2;
    }
    
    printf("  -> Número ímpar processado normalmente.\n");
    i++;
    goto inicio_loop;
    
    fim_loop:
    printf("Nenhum número par encontrado antes de encontrar 0 ou negativo.\n");
    return -1;
}

int main() {
    int lista1[] = {3, 7, 4, 0, 2};
    int tamanho1 = 5;
    
    printf("TESTE 1:\n");
    int resultado1 = processar_lista(lista1, tamanho1);
    printf("Resultado: %d\n\n", resultado1);
    
    int lista2[] = {-1, 5, -3, 8, 0};
    int tamanho2 = 5;
    
    printf("TESTE 2:\n");
    int resultado2 = processar_lista(lista2, tamanho2);
    printf("Resultado: %d\n\n", resultado2);
    
    int lista3[] = {1, 3, 5, 0, 7};
    int tamanho3 = 5;
    
    printf("TESTE 3:\n");
    int resultado3 = processar_lista(lista3, tamanho3);
    printf("Resultado: %d\n\n", resultado3);
    
    printf("TESTE COM GOTO:\n");
    int resultado_goto = processar_lista_com_goto(lista1, tamanho1);
    printf("Resultado: %d\n\n", resultado_goto);
    
    printf("=== ANÁLISE COMPARATIVA ===\n");
    printf("VANTAGENS DAS ALTERNATIVAS MODERNAS:\n");
    printf("1. BREAK: Para o laço de forma clara e controlada\n");
    printf("2. CONTINUE: Pula para a próxima iteração de forma explícita\n");
    printf("3. RETURN: Sai da função de forma limpa e retorna valor\n");
    printf("\nDESVANTAGENS DO GOTO:\n");
    printf("1. Código mais difícil de ler e entender\n");
    printf("2. Fluxo de controle não linear\n");
    printf("3. Maior propensão a bugs\n");
    printf("4. Dificulta manutenção e depuração\n");
    printf("5. Não segue princípios de programação estruturada\n");
    
    return 0;
}
