# Atividades Capítulo 8 - Estruturas de Controle

Este projeto contém as implementações das atividades do Capítulo 8 sobre estruturas de controle em programação.

## Arquivos Incluídos

### Atividade 1 - Estruturas de Repetição
- `atividade1.c` - Comparação entre goto, while e for

### Atividade 2 - Seleção Múltipla
- `atividade2.c` - Menu interativo em C usando switch/case
- `atividade2.py` - Menu interativo em Python usando if/elif/else

### Atividade 3 - Alternativas ao goto
- `atividade3.c` - Demonstração de break, continue e return em C
- `atividade3.py` - Demonstração de break, continue e return em Python

### Documentação
- `analise_comparativa.md` - Análise detalhada das implementações
- `atividades_capitulo8.md` - Enunciado original das atividades

## Como Compilar e Executar

### Programas em C

```bash
gcc -o atividade1 atividade1.c
gcc -o atividade2 atividade2.c
gcc -o atividade3 atividade3.c

./atividade1
./atividade2
./atividade3
```

### Programas em Python

```bash
python atividade2.py
python atividade3.py
```

## Funcionalidades

### Atividade 1
- Demonstra a evolução das estruturas de repetição
- Compara goto, while e for
- Inclui análise comparativa

### Atividade 2
- Menu interativo com 3 opções
- Calcula quadrado e fatorial
- Implementado em C e Python
- Tratamento de erros incluído

### Atividade 3
- Demonstra break, continue e return
- Compara com implementação usando goto
- Múltiplos casos de teste
- Análise das vantagens das alternativas modernas

## Requisitos

- **C**: Compilador GCC ou compatível
- **Python**: Python 3.x
- **Sistema**: Windows, Linux ou macOS

