def processar_lista(lista):
    """
    Função que demonstra break, continue e return
    """
    print("=== PROCESSANDO LISTA COM ALTERNATIVAS AO GOTO ===")
    print(f"Lista: {lista}")
    print()
    
    for i, elemento in enumerate(lista):
        print(f"Processando elemento {i}: {elemento}")
        
        if elemento == 0:
            print("  -> Encontrado 0! Parando execução com BREAK.")
            break
        
        if elemento < 0:
            print("  -> Número negativo encontrado! Pulando com CONTINUE.")
            continue
        
        if elemento % 2 == 0:
            print("  -> Primeiro número par encontrado! Retornando o dobro com RETURN.")
            return elemento * 2
        
        print("  -> Número ímpar processado normalmente.")
    
    print("Nenhum número par encontrado antes de encontrar 0 ou negativo.")
    return -1  

def processar_lista_com_goto_simulado(lista):
    """
    Função que demonstra como seria com goto (simulado com flags)
    """
    print("\n=== VERSÃO SIMULANDO GOTO (PARA COMPARAÇÃO) ===")
    print(f"Lista: {lista}")
    print()
    
    i = 0
    while i < len(lista):
        elemento = lista[i]
        print(f"Processando elemento {i}: {elemento}")
        
        if elemento == 0:
            print("  -> Encontrado 0! Parando execução (simulando GOTO).")
            break
        
        if elemento < 0:
            print("  -> Número negativo encontrado! Pulando (simulando GOTO).")
            i += 1
            continue
        
        if elemento % 2 == 0:
            print("  -> Primeiro número par encontrado! Retornando o dobro (simulando GOTO).")
            return elemento * 2
        
        print("  -> Número ímpar processado normalmente.")
        i += 1
    
    print("Nenhum número par encontrado antes de encontrar 0 ou negativo.")
    return -1

def main():
    lista1 = [3, 7, 4, 0, 2]
    
    print("TESTE 1:")
    resultado1 = processar_lista(lista1)
    print(f"Resultado: {resultado1}\n")
    
    lista2 = [-1, 5, -3, 8, 0]
    
    print("TESTE 2:")
    resultado2 = processar_lista(lista2)
    print(f"Resultado: {resultado2}\n")
    
    lista3 = [1, 3, 5, 0, 7]
    
    print("TESTE 3:")
    resultado3 = processar_lista(lista3)
    print(f"Resultado: {resultado3}\n")
    
    print("TESTE SIMULANDO GOTO:")
    resultado_goto = processar_lista_com_goto_simulado(lista1)
    print(f"Resultado: {resultado_goto}\n")
    
    print("=== ANÁLISE COMPARATIVA ===")
    print("VANTAGENS DAS ALTERNATIVAS MODERNAS:")
    print("1. BREAK: Para o laço de forma clara e controlada")
    print("2. CONTINUE: Pula para a próxima iteração de forma explícita")
    print("3. RETURN: Sai da função de forma limpa e retorna valor")
    print("\nDESVANTAGENS DO GOTO:")
    print("1. Código mais difícil de ler e entender")
    print("2. Fluxo de controle não linear")
    print("3. Maior propensão a bugs")
    print("4. Dificulta manutenção e depuração")
    print("5. Não segue princípios de programação estruturada")
    print("\nPYTHON E AS ALTERNATIVAS:")
    print("- Python não possui goto nativo")
    print("- break, continue e return são as formas recomendadas")
    print("- Código mais limpo e legível")
    print("- Melhor para manutenção e depuração")

if __name__ == "__main__":
    main()
