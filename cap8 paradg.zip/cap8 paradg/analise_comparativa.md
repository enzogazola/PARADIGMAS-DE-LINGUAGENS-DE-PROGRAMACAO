# Análise Comparativa - Atividades Capítulo 8

## Atividade 1 - Estruturas de Repetição

### Comparação entre goto, while e for:

**Código original com goto:**
- Funcionalmente correto, mas difícil de ler
- Fluxo de controle não linear
- Pode gerar "código espaguete" em programas maiores

**Versão com while:**
- Mais legível e estruturada
- Condição de parada explícita
- Fluxo linear e fácil de seguir

**Versão com for:**
- Mais concisa e expressiva
- Ideal para laços controlados por contador
- Reduz possibilidade de erros
- Concentra inicialização, condição e incremento em uma linha

**Conclusão:** A versão com `for` é a mais clara e adequada para este tipo de problema.

## Atividade 2 - Seleção Múltipla

### Comparação entre C (switch/case) e Python (if/elif/else):

**Implementação em C:**
- `switch/case` é mais eficiente para múltiplas opções
- Sintaxe mais limpa para menus
- Melhor performance em tempo de execução
- Estrutura mais organizada

**Implementação em Python:**
- `if/elif/else` é mais flexível
- Permite condições complexas
- Tratamento de exceções mais natural
- Código mais legível para iniciantes

**Conclusão:** Para menus simples, C com `switch/case` é mais adequado. Para lógica complexa, Python com `if/elif/else` oferece mais flexibilidade.

## Atividade 3 - Alternativas ao goto

### Vantagens das alternativas modernas:

**break:**
- Para o laço de forma clara e controlada
- Fluxo de controle previsível
- Fácil de entender e manter

**continue:**
- Pula para a próxima iteração de forma explícita
- Mantém a estrutura do laço
- Reduz complexidade do código

**return:**
- Sai da função de forma limpa
- Retorna valor de forma clara
- Facilita depuração

### Desvantagens do goto:
- Código mais difícil de ler e entender
- Fluxo de controle não linear
- Maior propensão a bugs
- Dificulta manutenção e depuração
- Não segue princípios de programação estruturada

**Conclusão:** As alternativas modernas (`break`, `continue`, `return`) são superiores ao `goto` em todos os aspectos, proporcionando código mais legível, manutenível e menos propenso a erros.

## Resumo Geral

As estruturas de controle modernas (laços estruturados, seleção múltipla, e alternativas ao goto) representam uma evolução significativa na programação, oferecendo:

1. **Melhor legibilidade:** Código mais fácil de entender
2. **Maior manutenibilidade:** Facilita modificações futuras
3. **Menor propensão a erros:** Estruturas mais seguras
4. **Melhor depuração:** Fluxo de controle mais previsível
5. **Padrões estabelecidos:** Seguem boas práticas de programação

O `goto` foi útil em seu tempo, mas as alternativas modernas são claramente superiores para a programação contemporânea.
